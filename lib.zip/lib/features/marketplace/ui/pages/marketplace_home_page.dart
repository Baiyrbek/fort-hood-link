import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../bloc/marketplace_bloc.dart';
import '../../bloc/marketplace_event.dart';
import '../../bloc/marketplace_state.dart';
import '../widgets/listing_card.dart';

class MarketplaceHomePage extends StatefulWidget {
  final VoidCallback? onNavigateToSell;

  const MarketplaceHomePage({
    super.key,
    this.onNavigateToSell,
  });

  @override
  State<MarketplaceHomePage> createState() => _MarketplaceHomePageState();
}

class _MarketplaceHomePageState extends State<MarketplaceHomePage> {
  final TextEditingController _searchController = TextEditingController();
  final List<String> _categories = [
    'All',
    'Electronics',
    'Furniture',
    'Gaming',
    'Sports',
    'Cars',
  ];
  int? _previousListingCount;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<MarketplaceBloc, MarketplaceState>(
      listenWhen: (previous, current) {
        // Sync search controller
        if (previous.query != current.query) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted && _searchController.text != current.query) {
              _searchController.text = current.query;
            }
          });
        }
        // Detect create by comparing listing counts (only on create, not initial load)
        final previousCount = previous.allListings.length;
        final currentCount = current.allListings.length;
        return currentCount > previousCount && _previousListingCount != null;
      },
      listener: (context, state) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Listing posted')),
        );
        _previousListingCount = state.allListings.length;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Home'),
        ),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Search items...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                ),
                onChanged: (value) {
                  context.read<MarketplaceBloc>().add(
                        SearchQueryChanged(value),
                      );
                },
              ),
            ),
            BlocBuilder<MarketplaceBloc, MarketplaceState>(
              builder: (context, state) {
                return SizedBox(
                  height: 50,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    itemCount: _categories.length,
                    itemBuilder: (context, index) {
                      final category = _categories[index];
                      // "All" is selected when selectedCategory is null
                      // Other categories are selected when selectedCategory matches
                      final isSelected = category == 'All'
                          ? state.selectedCategory == null
                          : state.selectedCategory == category;

                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          label: Text(category),
                          selected: isSelected,
                          onSelected: (_) {
                            // Always dispatch the event when chip is tapped
                            // "All" dispatches null, others dispatch the category name
                            context.read<MarketplaceBloc>().add(
                                  CategorySelected(
                                    category == 'All' ? null : category,
                                  ),
                                );
                          },
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            Expanded(
              child: BlocBuilder<MarketplaceBloc, MarketplaceState>(
                builder: (context, state) {
                  if (_previousListingCount == null && !state.loading) {
                    _previousListingCount = state.allListings.length;
                  }

                  if (state.loading) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  if (state.errorMessage != null) {
                    return Center(
                      child: Text('Error: ${state.errorMessage}'),
                    );
                  }

                  if (state.visibleListings.isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'No listings yet',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Be the first to post something.',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey,
                            ),
                          ),
                          const SizedBox(height: 24),
                          ElevatedButton(
                            onPressed: widget.onNavigateToSell,
                            child: const Text('Create listing'),
                          ),
                        ],
                      ),
                    );
                  }

                  return Padding(
                    padding: const EdgeInsets.all(12),
                    child: GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 0.68,
                      ),
                      itemCount: state.visibleListings.length,
                      itemBuilder: (context, index) {
                        return ListingCard(
                          listing: state.visibleListings[index],
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
